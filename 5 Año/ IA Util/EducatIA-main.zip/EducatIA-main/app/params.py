openai_api_key = "Ingresa Tu API Key de OpenAI"

mongodb_conn_string = "mongodb+srv://cristianarayac2:1234321@cluster0.p8v1v.mongodb.net/"
db_name = "education"
collection_name = "materias"
index_name = "vector_index"
