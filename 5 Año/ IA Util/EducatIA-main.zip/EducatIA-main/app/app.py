from flask import Flask, request, jsonify, render_template, url_for, flash, redirect, session
import os
import json
import csv
import openai
from PIL import Image
from io import BytesIO
import base64
import extract_data
from werkzeug.security import generate_password_hash, check_password_hash
#----------------------------------------------
from pymongo import MongoClient
from langchain_openai import OpenAIEmbeddings
from langchain_mongodb import MongoDBAtlasVectorSearch
from langchain_community.document_loaders import DirectoryLoader
from langchain_openai import OpenAI
from langchain.chains import RetrievalQA
import gradio as gr
from gradio.themes.base import Base
import params
#----------------------------------------------
import logging
from bson import ObjectId

logging.basicConfig(level=logging.INFO)  
logger = logging.getLogger(__name__)

app = Flask(__name__, static_url_path='/static', static_folder='static')
app.secret_key = '2c769f21f5b64d7d9a4e8eb6a94b2e76bc781d945f2b1c92edaa3f4af7c8964e'

openai.api_key = os.getenv('OPENAI_API_KEY')

HISTORIAL_FILE = 'historial.json'


def cargar_historial(user_id):
    db = client["educatIA_DB"]  
    historial_collection = db["historiales"]  
    """Cargar el historial de un usuario desde MongoDB."""
    historial_data = historial_collection.find({"user_id": user_id})
    historial = []
    for doc in historial_data:
        historial.extend(doc.get('historial', []))  # Añadir los historiales de cada documento
    return historial

def obtener_necesidad_por_user_id(user_id):
    # Conectar al cliente de MongoDB
    # Seleccionar la base de datos y la colección
    db = client["educatIA_DB"]  
    coleccion = db["promts"]
    
    # Buscar el documento que cumpla con el user_id
    documento = coleccion.find_one({"user_id": user_id}, {"_id": 0, "necesidad": 1})
    
    if documento:
        return documento.get("necesidad", None)  # Retorna el valor de 'necesidad' o None si no existe
    else:
        return None  # Si no se encuentra el documento

def guardar_historial(user_id, historial):
    """Guardar el historial de un usuario en MongoDB."""
    db = client["educatIA_DB"]  
    historial_collection = db["historiales"]  
    historial_collection.update_one(
        {"user_id": user_id},
        {"$set": {"historial": historial}},
        upsert=True  # Si no existe, lo crea
    )

def guardar_prompt(user_id, necesidad):
    """Guardar el historial de un usuario en MongoDB."""
    db = client["educatIA_DB"]  
    historial_collection = db["promts"]  
    historial_collection.update_one(
        {"user_id": user_id},
        {"$set": {"necesidad": necesidad}},
        upsert=True  # Si no existe, lo crea
    )

def cargar_prompts(filename='agronomo_prompt.json'):
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            prompts = json.load(file)
            for prompt in prompts:
                historial.append({"role": prompt["role"], "content": prompt["content"]})

cargar_prompts()

@app.route('/check_survey')
def check_survey():
    if 'user_id' in session:
        user_id = session['user_id']
        survey_collection = db["usuarios"]

        # Convertir el user_id a ObjectId antes de buscar en la base de datos
        user = survey_collection.find_one({"_id": ObjectId(user_id)})
        if user and user.get("hasCompletedSurvey", False):
            return jsonify({"hasCompletedSurvey": True})
        else:
            return jsonify({"hasCompletedSurvey": False})
    return jsonify({"hasCompletedSurvey": False})

@app.route('/')
def home():
    return redirect(url_for('index'))

@app.route('/index')
def index():
    if 'user_id' in session:
        user_id = session['user_id']
        historial = cargar_historial(user_id)
        return render_template('index.html', historial=historial)
    else:
        return redirect(url_for('loging'))
#--------------------------------------------------------------------
@app.route('/loging', methods=['GET', 'POST'])
def loging():
    db = client["educatIA_DB"] 
    users_collection = db["usuarios"]  

    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        if not (email and password):
            flash('Todos los campos son obligatorios.')
            logger.info("Fallo: Campos incompletos.")  
            return redirect(url_for('loging'))

        user = users_collection.find_one({"email": email})
        logger.info(f"Usuario buscado: {email}")  
        if user:
            logger.info(f"Usuario encontrado en la base de datos: {user['first_name']}")
        else:
            logger.warning("Usuario no encontrado en la base de datos.")

        if user and check_password_hash(user['password'], password):
            if not user.get('hasCompletedSurvey', False):
                # Mostrar el modal de encuesta
                flash('Por favor completa la encuesta para personalizar tu experiencia.')
            session['user_id'] = str(user['_id'])
            session['user_name'] = user['first_name']
            flash('Inicio de sesión exitoso.')
            logger.info(f"Inicio de sesión exitoso para: {user['first_name']}")
            users_collection = db["promts"] 
            if not users_collection.find_one({"user_id": session['user_id']}):
                logger.info("No existe promp, creando uno")
                necesidad = obtenerEncuesta(user['email'])
                guardar_prompt(session['user_id'],{"role": "system", "content": necesidad})
            return redirect(url_for('index'))
        else:
            flash('Correo o contraseña incorrectos.')
            logger.warning("Fallo: Contraseña incorrecta o usuario no registrado.")
            return redirect(url_for('loging'))

    logger.info("Método no es POST, cargando formulario.")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user_name', None)
    flash('Has cerrado sesión exitosamente.')
    logger.info("Sesión cerrada.")
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    db = client["educatIA_DB"] 
    users_collection = db["usuarios"] 
    if request.method == 'POST':
        # Recibir datos del formulario
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # Validaciones básicas
        if not (first_name and last_name and email and password and confirm_password):
            flash('Todos los campos son obligatorios.')
            return redirect(url_for('register'))

        if password != confirm_password:
            flash('Las contraseñas no coinciden.')
            return redirect(url_for('register'))

        # Verificar si el email ya está registrado
        if users_collection.find_one({"email": email}):
            flash('El email ya está registrado.')
            return redirect(url_for('register'))

        # Insertar el usuario en MongoDB
        hashed_password = generate_password_hash(password)
        users_collection.insert_one({
            "first_name": first_name,
            "last_name": last_name,
            "email": email,
            "password": hashed_password,
            "hasCompletedSurvey": False
        })

        flash('Registro exitoso. Por favor, inicia sesión.')
        return redirect(url_for('loging'))  # Cambia 'login' si tu ruta es diferente

    return render_template('register.html')

#------------------------------------------------------------------------------------------
client = MongoClient("mongodb+srv://cristianarayac2:1234321@cluster0.p8v1v.mongodb.net/")
db = client["educatIA_DB"]
dbName = "education"
collectionName = "materias"
collection = client[dbName][collectionName]
index_name = "vector_index"
#---------------------------------------------
# Define the text embedding model
import os
import time
embeddings = OpenAIEmbeddings(openai_api_key=os.getenv('OPENAI_API_KEY'))

# Initialize the Vector Store

vectorStore = MongoDBAtlasVectorSearch( collection, embeddings )
#-----------------------------------------------

@app.route('/chat', methods=['POST'])
def chat():
    if 'user_id' not in session:
        return jsonify({"error": "No user session found"}), 401

    user_id = session['user_id']
    mensaje = request.json['mensaje']
    
    # Recupera los documentos de MongoDB Atlas
    docs = vectorStore.similarity_search(mensaje, K=10)
    app.logger.debug("Retrieved documents:", docs)
    
    # Realiza la consulta a OpenAI
    llm = OpenAI(openai_api_key=os.getenv('OPENAI_API_KEY'), temperature=0)
    retriever = vectorStore.as_retriever()
    qa = RetrievalQA.from_chain_type(llm, chain_type="stuff", retriever=retriever)
    retriever_output = qa.invoke(mensaje)
    
    # Obtener la respuesta generada
    respuesta_rag = retriever_output["result"]
    completion = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "Convierte el siguiente texto en HTML con etiquetas como <h3>, <p>, <strong>, <ul>, o <ol>, según corresponda. Usa <h3> para títulos y <p> para contenido principal. Resalta puntos importantes con <strong> o <em> y utiliza listas cuando sea necesario. No uses etiquetas innecesarias ni incluyas la etiqueta <html> ni <body>. Mantén un formato limpio y sin incluir etiquetas <html> o <body>. Este es el texto para convertir:"},
            {
                "role": "user",
                "content": respuesta_rag
            }
        ]
    )
    final_res = completion.choices[0].message.content
    # Cargar historial del usuario y añadir el nuevo mensaje
    historial = cargar_historial(user_id)
    historial.append({"role": "user", "content": mensaje})
    historial.append({"role": "system", "content": final_res})
    #promp_inicial_importante = obtener_necesidad_por_user_id(user_id)
    #logger.info("Respuesta del modelo: %s", promp_inicial_importante)
    # Guardar el historial actualizado en MongoDB
    guardar_historial(user_id, historial)

    return jsonify({"respuesta": final_res})


from datetime import datetime, timedelta

@app.route('/notificaciones')
def notificaciones():
    # Simulación de notificaciones con tiempo
    now = datetime.now()
    notifications = [
        {"id": 1, "message": "Nueva tarea asignada", "time": now - timedelta(hours=2)},
        {"id": 2, "message": "Clase programada para mañana", "time": now - timedelta(minutes=30)},
        {"id": 3, "message": "Entrega de proyecto en 2 días", "time": now - timedelta(days=1)}
    ]
    return render_template('inicio.html', notifications=notifications)

#--------------------------------------------------------------------------------------------------------
#                                       Encuesta de Google
import gspread
from google.oauth2.service_account import Credentials
@app.route('/obtenerEncuesta')
def obtenerEncuesta(email):
    try:
        # Definir el acceso a Google Sheets
        SCOPES = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]
        creds = Credentials.from_service_account_file('cogent-sweep-407413-d3978ca9c102.json', scopes=SCOPES)
        gc = gspread.authorize(creds)
        logger.info("Autenticación con Google Sheets exitosa.")
    except Exception as e:
        logger.error(f"Error en la autenticación con Google Sheets: {e}")
        exit()

    try:
        # Abrir la hoja de cálculo de Google Sheets
        spreadsheet_url = "https://docs.google.com/spreadsheets/d/1f4gJudHkyVQXGzzObdrN0JcqCHdIDCVF1GLxiAbpmSU/edit#gid=1105422071"
        spreadsheet = gc.open_by_url(spreadsheet_url)
        logger.info("Hoja de cálculo abierta exitosamente.")
    except Exception as e:
        logger.error(f"Error al abrir la hoja de cálculo de Google Sheets: {e}")
        exit()

    try:
        # Seleccionar la hoja específica por nombre o índice
        worksheet = spreadsheet.get_worksheet(0)  # o puedes usar .worksheet('NombreDeLaHoja')
        logger.info("Hoja de trabajo seleccionada exitosamente.")
    except Exception as e:
        logger.error(f"Error al seleccionar la hoja de trabajo: {e}")
        exit()

    # Lista completa de encabezados esperados
    expected_headers = [
        'Marca temporal',
        'Nombre y apellidos',
        'Correo electrónico',
        'Rut (Ej: XX.XXX.XXX-X)',
        'Edad (Número)',
        'Número telefónico',
        '¿A qué se dedica?',
        'Si su respuesta fue "trabajo" o "trabajo y estudio", ¿Cuál es su jornada de trabajo?. En caso contrario responda "No aplica".',
        'Si su respuesta fue "estudio" o "trabajo y estudio", ¿En qué tipo de educación se encuentra?. En caso contrario responda "No aplica".',
        '¿Cuál(es) de los siguientes dispositivos tiene y/o se puede conseguir para utilizar la plataforma?',
        '¿Eres constante en el estudio?',
        '¿Crees que sabes estudiar?',
        '¿Encuentras fácilmente las ideas principales de lo que lees?',
        '¿Cuando estudias estás pendiente del teléfono y/o computador?',
        '¿El lugar donde estudias es libre de distracciones?',
        '¿Tienes un buen ambiente para estudiar en la casa?',
        '¿Prefieres leer el material en silencio?',
        '¿Haces mapas conceptuales y/o mentales?',
        '¿Tienes un lugar fijo para estudiar?',
        '¿Cumples con los plazos que te propones?',
        '¿Tienes claras las razones por las que estudias?',
        '¿Evitas estudiar a última hora?',
        '¿El estudio es para ti un medio para aprender?',
        '¿Tratas de entregar lo máximo de ti para obtener un buen resultado en diferentes ámbitos?',
        '¿Empleas estrategias visuales como esquemas o gráficos?',
        '¿Realizas una lectura rápida del texto , previo al estudio más detallado?',
        '¿El lugar donde estudias posee buena iluminación?',
        '¿Sientes que tienes el control de tu tiempo y tareas de estudio?',
        '¿Tomas descansos para recargar tu energía mental?',
        '¿Distribuyes tus materias de forma equilibrada a lo largo de la semana?',
        '¿Te resulta fácil mantenerte enfocado en tus objetivos académicos?',
        '¿Consideras efectivo tu método de memorización actual?',
        '¿Tienes una visión clara de cómo tu aprendizaje impactará en tu futuro?',
        '¿Buscas ayuda cuando tienes dificultades con un tema?',
        '¿Te sientes motivado a largo plazo por tus metas académicas?',
        '¿Te preparas con anticipación suficiente para tus evaluaciones o tareas importantes?',
        '¿Estudias regularmente, incluso cuando no hay evaluaciones cercanas?',
        '¿Prefieres entender los conceptos antes que memorizarlos?',
        '¿Te apoyas en herramientas digitales o recursos adicionales como videos o guías?',
        '¿Practicas con ejercicios o pruebas para evaluar lo aprendido?',
        '¿Evitas estudiar a última hora antes de un examen?',
        '¿Tienes confianza en tus habilidades para aprender y mejorar?',
        '¿Te premias o celebras tus logros cuando cumples tus objetivos?',	
        '¿Revisas los conceptos estudiados el día anterior para consolidarlos?',
        '¿Le gustaría prepararse para la prueba de Competencia Lectora?',	
        '¿Le gustaría prepararse para la prueba de Competencia Matemática M1?',
        '¿Le gustaría prepararse para la prueba de Competencia Matemática M2?',	
        '¿Le gustaría prepararse para la prueba de Ciencias?',	
        '¿Le gustaría prepararse para la prueba de Historia y Ciencias Sociales?'
    ]

    try:
        # Obtener los registros de la hoja de cálculo especificando los encabezados esperados
        rows = worksheet.get_all_records(expected_headers=expected_headers)
        logger.info(f"{len(rows)} registros obtenidos de la hoja de cálculo.")

        # Buscar el registro correspondiente al correo del usuario logueado
        user_record = next((row for row in rows if row['Correo electrónico'] == email), None)
        
        if user_record:
            logger.info(f"Usuario encontrado en la hoja de cálculo: {user_record}")
        else:
            logger.warning(f'No se encontró el correo {email} en la hoja de cálculo.')
    except Exception as e:
        logger.error(f"Error al obtener registros de la hoja de cálculo: {e}")
        exit()

    try:
        # Configuración de la API de OpenAI
        if not openai.api_key:
            raise ValueError("La API Key de OpenAI no está definida.")
        logger.info("API Key de OpenAI configurada correctamente.")
    except Exception as e:
        logger.error(f"Error en la configuración de la API de OpenAI: {e}")
        exit()

    # Cambiar la descripción del prompt inicial
    prompt_data = "Analiza los datos del estudiante con email {email} y dime qué tipo de nivel se encuentra actualmente, que necesidad tiene y que debe mejorar. Y en base a ello, adapta tus respuestas para ayudarlo a mejorar\n"
    for row in rows:
        # Verificar si la fila tiene el correo electrónico especificado
        if row.get('Correo electrónico') == email:
            # Añadir la fila correspondiente al prompt
            prompt_data += f"{row}\n"

    try:
        # Enviar el prompt a la API de OpenAI usando gpt-4o-mini
        response = openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Eres un asistente útil que analiza datos de estudiantes, para luego ayudarlos como un asistente/profesor en sus estudios requeridos u necesidades que tenga."},
                {"role": "user", "content": prompt_data}
            ],
            max_tokens=1200  # Define el límite según tus necesidades
        )
        generated_text = response.choices[0].message.content.strip()
        logger.info("Respuesta generada por el modelo de GPT correctamente.")
    except Exception as e:
        logger.error(f"Error al realizar la consulta a la API de OpenAI: {e}")
        exit()

    # Mostrar la respuesta
    logger.info("Respuesta del modelo: %s", generated_text)
    completion = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "Convierte el siguiente texto en HTML con etiquetas como <h3>, <p>, <strong>, <ul>, o <ol>, según corresponda. Usa <h3> para títulos y <p> para contenido principal. Resalta puntos importantes con <strong> o <em> y utiliza listas cuando sea necesario. No uses etiquetas innecesarias ni incluyas la etiqueta <html> ni <body>. Mantén un formato limpio y sin incluir etiquetas <html> o <body>. Este es el texto para convertir:"},
            {
                "role": "user",
                "content": generated_text
            }
        ]
        )
    final_res = completion.choices[0].message.content
    return final_res


#--------------------------------------------------------------------------------------------------------
@app.route('/upload_image', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file:
        try:
            # Lee el archivo y conviértelo a base64
            image_data = file.read()
            base64_image = base64.b64encode(image_data).decode('utf-8')

            # Obtén la pregunta desde la solicitud
            question = request.form.get('question', "What’s in this image?")

            response = openai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": question},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64_image}"
                                },
                            },
                        ],
                    }
                ],
                max_tokens=300,
            )

            return jsonify({"response": response.choices[0].message.content})

        except Exception as e:
            return jsonify({"error": str(e)}), 500

    return jsonify({"error": "Invalid request"}), 400

def generar_preguntas(asignatura):
    # Prompt para que OpenAI genere preguntas según la asignatura
    prompt_data = f"Genera 3 preguntas de opción múltiple sobre {asignatura} para un examen de nivel escolar. Asegúrate de que cada pregunta esté en su propio bloque, con las opciones numeradas de la 'a' a la 'd'. Indica la respuesta correcta al final de cada pregunta de forma clara, en el formato 'Respuesta correcta: [letra de la opción]', sin caracteres raros ni saltos de línea."
    
    # Enviar el prompt a la API de OpenAI usando gpt-4o-mini
    try:
        response = openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "system", "content": "Eres un asistente útil que ayuda a los estudiantes para la preparación para la prueba paes."},
                      {"role": "user", "content": prompt_data}],
            max_tokens=1200
        )

        # Obtener la respuesta generada
        preguntas_texto = response.choices[0].message.content.strip()
        logger.info(f"Respuesta generada por OpenAI: {preguntas_texto}")

        # Procesar las preguntas y opciones
        lineas = preguntas_texto.split("\n")
        
        preguntas = []
        pregunta_actual = None
        opciones = []
        respuesta_correcta = None

        for linea in lineas:
            linea = linea.strip()

            # Detectar la pregunta (termina en "?")
            if linea.endswith("?"):
                if pregunta_actual:
                    preguntas.append({
                        "pregunta": pregunta_actual,
                        "opciones": opciones,
                        "respuesta_correcta": respuesta_correcta
                    })
                pregunta_actual = linea
                opciones = []
                respuesta_correcta = None

            # Detectar opciones (líneas que empiezan con "a)", "b)", "c)", "d)")
            elif linea.startswith(("a)", "b)", "c)", "d)")):
                opcion = linea.split(")")[1].strip()  # Guardar solo la opción
                opciones.append(opcion)

            # Detectar la respuesta correcta (al final de la pregunta)
            if "Respuesta correcta:" in linea:
                respuesta_correcta = linea.split("Respuesta correcta:")[1].strip()

        # Asegurarse de que la última pregunta se guarde
        if pregunta_actual:
            preguntas.append({
                "pregunta": pregunta_actual,
                "opciones": opciones,
                "respuesta_correcta": respuesta_correcta
            })

        # Verificar si el archivo JSON existe, si no, crear uno nuevo
        if not os.path.exists('preguntas.json'):
            logger.info("El archivo preguntas.json no existe, se creará uno nuevo.")
        else:
            os.remove('preguntas.json')  # Asegúrate de pasar el nombre del archivo entre comillas
            logger.info("El archivo preguntas.json ha sido eliminado.")
        
        # Guardar las preguntas en el archivo JSON
        with open('preguntas.json', 'w', encoding='utf-8') as f:
            json.dump(preguntas, f, ensure_ascii=False, indent=4)
        
        logger.info(f"Preguntas guardadas correctamente en 'preguntas.json'.")

    except Exception as e:
        logger.error(f"Error al generar preguntas: {e}")


@app.route("/realizar_prueba/<asignatura>")
def realizar_prueba(asignatura):
    # Generar preguntas dinámicamente con OpenAI (o desde otro lugar)
    preguntas_generadas = generar_preguntas(asignatura)
    
    if preguntas_generadas:
        # Guardar las preguntas generadas en un archivo JSON
        with open('preguntas.json', 'w', encoding='utf-8') as f:
            json.dump(preguntas_generadas, f, ensure_ascii=False, indent=4)
    
    # Cargar las preguntas desde el archivo JSON
    with open('preguntas.json', 'r', encoding='utf-8') as f:
        preguntas_json = json.load(f)
    
    return render_template("prueba.html", asignatura=asignatura, preguntas=preguntas_json)

@app.route("/verificar", methods=["POST"])
def verificar_respuestas():
    data = request.get_json()
    asignatura = data.get("asignatura")
    respuestas = data.get("respuestas")
    
    # Cargar las preguntas y respuestas correctas desde el archivo JSON
    with open('preguntas.json', 'r', encoding='utf-8') as f:
        preguntas = json.load(f)
    
    # Verificar respuestas
    correctas = 0
    detalles_respuestas = []
    
    for i, pregunta in enumerate(preguntas):  # Usamos enumerate para obtener el índice
        respuesta_usuario = respuestas[i]  # Acceder por índice
        
        # Depuración: Imprimir las respuestas para verificar su tipo y valor
        print(f"Pregunta {i}: {pregunta['pregunta']}")
        print(f"Respuesta correcta: {pregunta['respuesta_correcta']}")
        print(f"Respuesta del usuario: {respuesta_usuario}")
        
        # Verificar si la respuesta es correcta
        # Asegúrate de comparar el tipo adecuado (por ejemplo, convertir a string si es necesario)
        es_correcta = str(respuesta_usuario).strip() == str(pregunta["respuesta_correcta"]).strip()
        
        if es_correcta:
            correctas += 1
        
        detalles_respuestas.append({
            "pregunta": pregunta["pregunta"],  # Aquí solo enviamos la pregunta
            "respuesta_correcta": pregunta["respuesta_correcta"],
            "respuesta_usuario": respuesta_usuario,
            "es_correcta": es_correcta
        })
    
    # Calcular porcentaje
    total = len(preguntas)
    porcentaje = (correctas / total) * 100
    
    return jsonify({
        "correctas": correctas,
        "total": total,
        "porcentaje": porcentaje,
        "detalles_respuestas": detalles_respuestas
    })

@app.route('/update_survey_status', methods=['POST'])
def update_survey_status():
    if 'user_id' in session:
        user_id = session['user_id']
        db["usuarios"].update_one(
            {"_id": ObjectId(user_id)},
            {"$set": {"hasCompletedSurvey": True}}
        )
        return jsonify({"message": "Estado de la encuesta actualizado con éxito"}), 200
    return jsonify({"message": "Usuario no encontrado o no autenticado"}), 404

@app.route('/prompt_base', methods=['GET'])
def prompt_base():
    if 'user_id' in session:
        user_id = session['user_id']
        promp_collection = db["promts"]

        # Buscar el prompt del usuario en la colección
        prompt = promp_collection.find_one({"user_id": user_id})

        if prompt:
            # Mostrar el prompt si existe
            return render_template('prompt_base.html', prompt=prompt["necesidad"]["content"])
        else:
            # Si no existe, mostrar un mensaje indicando que no hay prompt generado
            return render_template('prompt_base.html', prompt="No hay análisis generado todavía.")
    return redirect(url_for('loging'))

@app.route('/update_prompt', methods=['POST'])
def update_prompt():
    if 'user_id' in session:
        user_id = session['user_id']
        data = request.get_json()
        updated_content = data.get("content")

        # Actualizar el contenido del prompt en la base de datos
        promp_collection = db["promts"]
        result = promp_collection.update_one(
            {"user_id": user_id},
            {"$set": {"necesidad.content": updated_content}}
        )

        if result.matched_count > 0:
            return jsonify({"success": True, "message": "Prompt actualizado con éxito"}), 200
        else:
            return jsonify({"success": False, "message": "No se encontró el prompt"}), 404

    return jsonify({"success": False, "message": "Usuario no autenticado"}), 403


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')