// Función para enviar mensaje
async function sendMessage() {
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');

    const userMessage = userInput.value.trim();
    if (!userMessage) return; // Evita mensajes vacíos

    // Agregar el mensaje del usuario al chat
    appendMessage(userMessage, 'user', 'alert-info');

    // Limpiar el campo de entrada
    userInput.value = '';

    // Desplazar hacia abajo el chat
    scrollChatToBottom(chatBox);

    try {
        // Hacer la solicitud al servidor
        const response = await fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ mensaje: userMessage })
        });

        if (response.ok) {
            const data = await response.json();

            // Agregar la respuesta del servidor al chat
            appendMessage(data.respuesta, 'assistant', 'alert-light');

            // Renderizar ecuaciones matemáticas si es necesario
            if (typeof MathJax !== 'undefined') {
                MathJax.typesetPromise();
            }
        } else {
            console.error("Error al obtener respuesta del servidor.");
            appendMessage('Error al procesar tu mensaje. Intenta de nuevo.', 'assistant', 'alert-danger');
        }
    } catch (error) {
        console.error("Error en la solicitud:", error);
        appendMessage('Error al conectar con el servidor. Revisa tu conexión.', 'assistant', 'alert-danger');
    } finally {
        // Enfocar nuevamente el campo de entrada
        userInput.focus();
        scrollChatToBottom(chatBox);
    }
}

// Función para agregar mensajes al chat
function appendMessage(content, role, alertClass) {
    const chatBox = document.getElementById('chat-box');

    // Crear el contenedor del mensaje
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', role);

    // Crear el alert para el mensaje
    const alertElement = document.createElement('div');
    alertElement.classList.add('alert', alertClass, 'rounded');
    alertElement.innerHTML  = content;

    // Agregar el alert al contenedor del mensaje
    messageElement.appendChild(alertElement);

    // Agregar el mensaje al chat
    chatBox.appendChild(messageElement);
}

// Función para desplazar el chat hacia el final
function scrollChatToBottom(chatBox) {
    chatBox.scrollTop = chatBox.scrollHeight;
}

// Agregar listener para enviar mensaje al presionar "Enter"
document.addEventListener('DOMContentLoaded', () => {
    const userInput = document.getElementById('user-input');

    userInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault(); // Evita un salto de línea
            sendMessage();
        }
    });
});

// Desplazar el chat hacia el final al cargar la página
window.addEventListener('load', () => {
    const chatBox = document.getElementById('chat-box');
    if (chatBox) scrollChatToBottom(chatBox);
});
