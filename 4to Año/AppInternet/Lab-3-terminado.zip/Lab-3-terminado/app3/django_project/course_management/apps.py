from django.apps import AppConfig


class CourseManagementConfig(AppConfig):
    name = 'course_management'
